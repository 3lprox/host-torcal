// lista.js 
const searchResults = [
  { title: "Wikipedia en español", url: "https://es.wikipedia.org/", description: "La enciclopedia libre que todos pueden editar." },
  { title: "DuckDuckGo", url: "https://duckduckgo.com/", description: "El motor de búsqueda que no te rastrea." },
  { title: "Linux.org", url: "https://www.linux.org/", description: "Página oficial de la comunidad de Linux." },
  { title: "Youtube", url: "https://www.youtube.com/", description: "Pagina web de videos, la mas popular"},
  { title: "Github", url: "https://www.github.com/", description: "Pagina web de proyectos"},
  { title: "Reddit", url: "https://www.reddit.com/", description: "Pagina web de foros"},
  { title: "Linkedin", url: "https://www.linkedin.com/", description: "Buscador de trabajo"},
  { title: "X", url: "https://www.x.com/", description: "Discute y publica post"},
];